<?php
    $server="localhost";
    $username="root";
    $password="";
    $database="school_db";
    $flag='F';
    
    $con=mysqli_connect($server,$username,$password,$database);
    
    $sql="SELECT * FROM `student`;";
    $results = mysqli_query($con, $sql);

    if(!$con){
        die("Connection to this Database failed due to ".mysqli_connect_error());
    }

    if(isset($_POST['sub'])){
        $id = $_POST['sub']; 
            
        if( !empty($_POST['name'])){
            $name = $_POST['name']; 
            $sql="UPDATE `student` SET `name` = '$name' WHERE `student`.`student_id` = $id;";
            if($con->query($sql) == true){
                $flag='T';
            }
        }
        if( !empty($_POST['age'])){
            $age = $_POST['age']; 
            $sql="UPDATE `student` SET `age` = '$age' WHERE `student`.`student_id` = $id;";
            if($con->query($sql) == true){
                $flag='T';
            }
        }
        if( !empty($_POST['gender'])){
            $gender = $_POST['gender']; 
            $sql="UPDATE `student` SET `gender` = '$gender' WHERE `student`.`student_id` = $id;";
            if($con->query($sql) == true){
                $flag='T';
            }
        }
        if( !empty($_POST['phone'])){
            $phone = $_POST['phone']; 
            $sql="UPDATE `student` SET `phone` = '$phone' WHERE `student`.`student_id` = $id;";
            if($con->query($sql) == true){
                $flag='T';
            }
        }
        if( !empty($_POST['class'])){
            $class_id = $_POST['class']; 
            $sql="UPDATE `student` SET `class_id` = '$class_id' WHERE `student`.`student_id` = $id;";
            if($con->query($sql) == true){
                $flag='T';
            }
        }
        
        // $sql="UPDATE `student` SET `$column` = '$newvalue' WHERE `student`.`student_id` = $id;";
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Travel Form</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto|Sriracha&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="input.css">
    
</head>

<body>
    <div class="container">
        <h1>Welcome to Shri Sharadha HighSchool Student Updation form</h3>
        <p>Select student in the list
            <?php
                if(isset($_POST['up'])){
                    echo 'and enter the details of only thoses information which you want to update';
                }
            ?> 
        </p>
        <?php if($flag == 'T'): ?>
            <p class='submitMsg'>Sytudent data are now successfully updated, goto home page</p>
        <?php endif ?>

        <form method="post" action="./us.php">

            <div class="op">
                <label for="id">Pick student id that you want to update</label> 
                <select method="post" name="id" id="id">
                    <?php foreach ($results as $res) : ?>
                    <option name="id" value=<?php echo $res['student_id'];?>><?php echo $res['student_id'].' -   [ '.$res['name'].' ]' ; ?></option>
                    <?php endforeach ?>
                </select>
                <Button name="up">go</button>
            </div>

            <?php
                if(isset($_POST["up"])){
                    $sel_id=$_POST['id'];
                    $tsql="SELECT * FROM `student` WHERE `student_id` = $sel_id";
                    $tres=mysqli_query($con, $tsql);
                    $ans=mysqli_fetch_assoc($tres);
                }
            ?>

            <?php if(isset($_POST["up"])): ?>

                <p><?php echo 'Name : '.$ans['name']; ?></p>
                <input type="text" name="name" placeholder="Update Student name"> <br>
                
                <p><?php echo 'Age : '.$ans['age']; ?></p>
                <input type="number" name="age" placeholder="Update Student age"> <br>
                
                <p><?php echo 'Gender : '.$ans['gender']; ?></p>
                <div class="op">
                    <label for="gender">Update students gender</label> 
                    <select name="gender" id="gender">
                        <option name="gender" value="" selected disabled hidden>Update gender</option>
                        <option name="gender" value="male">Male</option>
                        <option name="gender" value="female">Female</option>
                    </select>
                </div>
                
                <p><?php echo 'Phone Number : '.$ans['phone']; ?></p>
                <input type="number" name="phone" placeholder="Update Students Phone Number"> <br>
                
                <?php
                    if($ans['class_id']==1){
                        $cid="8th a";
                    }
                    elseif($ans['class_id']==2)
                        $cid="8th b";
                    elseif($ans['class_id']==3)
                        $cid="8th c";
                    elseif($ans['class_id']==4)
                        $cid="9th a";
                    elseif($ans['class_id']==5)
                        $cid="9th b";
                    elseif($ans['class_id']==6)
                        $cid="9th c";
                    elseif($ans['class_id']==7)
                        $cid="10th a";
                    elseif($ans['class_id']==8)
                        $cid="10th b";
                    elseif($ans['class_id']==9)
                        $cid="10th c";
                ?>
                
                <p><?php echo 'class : '.$cid; ?> </p>
                <div class="op">
                    <label for="class">Update students class</label> 
                    <select name="class" id="class">
                        <option name="class" value="" selected disabled hidden>Update class</option>
                        <option name="class" value="1">8th   'A'</option>
                        <option name="class" value="2">8th   'B'</option>
                        <option name="class" value="3">8th   'C'</option>
                        <option name="class" value="4">9th   'A'</option>
                        <option name="class" value="5">9th  'B'</option>
                        <option name="class" value="6">9th  'C'</option>
                        <option name="class" value="7">10th  'A'</option>
                        <option name="class" value="8">10th  'B'</option>
                        <option name="class" value="9">10th  'C'</option>
                    </select>
                </div>
                
                <button class="btn" value= <?php echo $sel_id; ?> name="sub">Submit</button> <br>
            <?php endif ?>
            
    
    
            <div>
                <p class="link"> Finished adding the students ? <br> <a href="h1.html">Go back</a>  here</p>
            </div>
        </form>
    </div>
</body>
</html>

