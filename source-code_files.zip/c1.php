<?php
    $server="localhost";
    $username="root";
    $password="";
    $database="school_db";
    
    $con=mysqli_connect($server,$username,$password,$database);
    
    if(!$con){
        die("Connection to this Database failed due to ".mysqli_connect_error());
    }

    $sql="SELECT * FROM `class`;";
    $results = mysqli_query($con, $sql);
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <title>Document</title>
</head>
<body class="bg-success p-2 text-dark bg-opacity-25"> <br>
    <figure class="text-center">    
        <h1 class="border border-5 border-dark" >Class Information Details</h1>  <br> <br> <br> 
    </figure>   
    <div class="container-lg">
        <table class="table table-dark table-sm table-striped">
            <thead>
                <tr>
                  <th scope="col">Class_id</th>
                  <th scope="col">Class_name</thber</th>
                  <th scope="col">Class_section</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($results as $res) : ?>
                    <tr>
                        <td> <?php echo $res['class_id']."  ";  ?> </td>
                        <td> <?php echo $res['class_name']."  "; ?> </td>
                        <td> <?php echo $res['section']."  ";  ?> </td>
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>
</body>
<figure class="text-center">
        <div id="three" class="d-grid gap-2 d-md-block">
            <a href="h2.html" class="btn btn-danger" type="button">Go Back To Home</a>
        </div>
    </figure>
</html>