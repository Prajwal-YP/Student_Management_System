<?php
    $server="localhost";
    $username="root";
    $password="";
    $database="school_db";
    $flag='F';
    
    $con=mysqli_connect($server,$username,$password,$database);
    
    
    if(!$con){
        die("Connection to this Database failed due to ".mysqli_connect_error());
    }
    
    $sql="SELECT * FROM `teacher`;";
    $results = mysqli_query($con, $sql);
    if(isset($_POST['sub'])){
        $id = $_POST['sub']; 
            
        if( !empty($_POST['name'])){
            $name = $_POST['name']; 
            $sql="UPDATE `teacher` SET `name` = '$name' WHERE `teacher`.`teacher_id` = $id;";
            if($con->query($sql) == true){
                $flag='T';
            }
        }
        if( !empty($_POST['date'])){
            $date = date('Y-m-d', strtotime($_POST['date']));
            echo $date;
            $sql="UPDATE `teacher` SET `date_joined` = '$date' WHERE `teacher`.`teacher_id` = $id;";
            if($con->query($sql) == true){
                $flag='T';
            }
        }
        if( !empty($_POST['gender'])){
            $gender = $_POST['gender']; 
            $sql="UPDATE `teacher` SET `gender` = '$gender' WHERE `teacher`.`teacher_id` = $id;";
            if($con->query($sql) == true){
                $flag='T';
            }
        }
        if( !empty($_POST['phone'])){
            $phone = $_POST['phone']; 
            $sql="UPDATE `teacher` SET `phone` = '$phone' WHERE `teacher`.`teacher_id` = $id;";
            if($con->query($sql) == true){
                $flag='T';
            }
        }
        if( !empty($_POST['class'])){
            $class_id = $_POST['class']; 
            $sql="UPDATE `teacher` SET `class_id` = '$class_id' WHERE `teacher`.`teacher_id` = $id;";
            if($con->query($sql) == true){
                $flag='T';
            }
        }
        
        // $sql="UPDATE `student` SET `$column` = '$newvalue' WHERE `student`.`student_id` = $id;";
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Travel Form</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto|Sriracha&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="input.css">
    
</head>

<body>
    <div class="container">
        <h1>Welcome to Shri Sharadha HighSchool Teacher Updation form</h3>
        <p>Select techer in the list
            <?php
                if(isset($_POST['up'])){
                    echo 'and enter the details of only thoses information which you want to update';
                }
            ?> 
        </p>
        <?php if($flag == 'T'): ?>
            <p class='submitMsg'>Teacher data are now successfully updated, goto home page</p>
        <?php endif ?>

        <form method="post" action="./ut.php">

            <div class="op">
                <label for="id">Pick teacher id that you want to update</label> 
                <select method="post" name="id" id="id">
                    <?php foreach ($results as $res) : ?>
                    <option name="id" value=<?php echo $res['teacher_id'];?>><?php echo $res['teacher_id'].' -   [ '.$res['name'].' ]' ; ?></option>
                    <?php endforeach ?>
                </select>
                <Button name="up">go</button>
            </div>

            <?php
                if(isset($_POST["up"])){
                    $sel_id=$_POST['id'];
                    $tsql="SELECT * FROM `teacher` WHERE `teacher_id` = $sel_id";
                    $tres=mysqli_query($con, $tsql);
                    $ans=mysqli_fetch_assoc($tres);
                }
            ?>

            <?php if(isset($_POST["up"])): ?>

                <p><?php echo 'Name : '.$ans['name']; ?></p>
                <input type="text" name="name" placeholder="Update teachers name"> <br>

                <p><?php echo 'Gender : '.$ans['gender']; ?></p>
                <div class="op">
                    <label for="gender">Update teachers Gender </label> 
                    <select name="gender" id="gender">
                        <option name="gender" value="" selected disabled hidden> Update Gender </option>
                        <option name="gender" value="male">Male</option>
                        <option name="gender" value="female">Female</option>
                    </select>
                </div> <br>
                
                <p><?php echo 'Phone : '.$ans['phone']; ?></p>
                <input type="number" name="phone" placeholder= "Update teachers phone number" > <br>
                
                <p><?php echo 'Date_Joined : '.$ans['date_joined']; ?></p>
                <div class="op">
                    <label for="date"> Update date joined  </label>
                    <input type="date" name="date">
                </div> <br>
                
                <?php
                    if($ans['class_id']==1){
                        $cid="8th a";
                    }
                    elseif($ans['class_id']==2)
                        $cid="8th b";
                    elseif($ans['class_id']==3)
                        $cid="8th c";
                    elseif($ans['class_id']==4)
                        $cid="9th a";
                    elseif($ans['class_id']==5)
                        $cid="9th b";
                    elseif($ans['class_id']==6)
                        $cid="9th c";
                    elseif($ans['class_id']==7)
                        $cid="10th a";
                    elseif($ans['class_id']==8)
                        $cid="10th b";
                    elseif($ans['class_id']==9)
                        $cid="10th c";
                ?>
                
                <p><?php echo 'class : '.$cid; ?> </p>
                <div class="op">
                    <label for="class">Update class Assigned</label> 
                    <select name="class" id="class">
                        <option name="class" value="" selected disabled hidden> Update Class</option>
                        <option name="class" value="1">8th   'A'</option>
                        <option name="class" value="2">8th   'B'</option>
                        <option name="class" value="3">8th   'C'</option>
                        <option name="class" value="4">9th   'A'</option>
                        <option name="class" value="5">9th  'B'</option>
                        <option name="class" value="6">9th  'C'</option>
                        <option name="class" value="7">10th  'A'</option>
                        <option name="class" value="8">10th  'B'</option>
                        <option name="class" value="9">10th  'C'</option>
                    </select>
                </div> <br>
                <button class="btn" value= <?php echo $sel_id; ?> name="sub">Submit</button> <br>
            <?php endif ?>


            <div>
                <p class="link"> Finished adding the students ? <br> <a href="h1.html">Go back</a>  here</p>
            </div>
        </form>
    </div>
</body>
</html>