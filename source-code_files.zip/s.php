<?php
    $server="localhost";
    $username="root";
    $password="";
    $database="school_db";
    
    $con=mysqli_connect($server,$username,$password,$database);
    
    if(!$con){
        die("Connection to this Database failed due to ".mysqli_connect_error());
    }

    $c=0;

    $sql="SELECT * FROM `student`;";
    $results = mysqli_query($con, $sql);

    foreach ($results as $x){
        $c += 1;
    }
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="t.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <title>Document</title>
</head>
<body class="bg-success p-2 text-dark bg-opacity-25"> <br>
    <figure class="text-center">    
        <h1 class="border border-5 border-success" >Student Information Details</h1>  <br> <br> <br> 
    </figure> 
    
    <div id="ttl" >
        <p>Total number of Students --> <?php echo $c; ?> </p>
    </div>
    
    <div class="container-lg">
        <table class="table table-dark table-sm table-striped">
            <thead>
                <tr>
                  <th scope="col">Student_id</th>
                  <th scope="col">Name</th>
                  <th scope="col">Age</th>
                  <th scope="col">Gender</th>
                  <th scope="col">Phone</th>
                  <th scope="col">Class_Number</th>
                  <th scope="col">Section</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($results as $res) : ?>
                    <tr>
                        <td> <?php echo $res['student_id']."  ";  ?> </td>
                        <td> <?php echo $res['name']."  "; ?> </td>
                        <td> <?php echo $res['age']."  ";  ?> </td>
                        <td> <?php echo $res['gender']."  ";  ?> </td>
                        <td> <?php echo $res['phone']."  ";  ?> </td>

                        <?php
                            $id=$res['class_id'];
                            $sql2="SELECT * FROM `class` WHERE `class_id` = $id;";
                            $results2 = mysqli_query($con, $sql2);
                            $res2 = mysqli_fetch_assoc($results2);
                        ?>

                        <td> <?php echo $res2['class_name']."  ";  ?> </td>
                        <td> <?php echo $res2['section']."  ";  ?> </td>
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>
    <figure class="text-center">
        <div id="three" class="d-grid gap-2 d-md-block">
            <a href="h1.html" class="btn btn-danger" type="button">Go Back To Home</a>
        </div>
    </figure>
</body>
</html>