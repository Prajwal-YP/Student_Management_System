<?php
    $con=mysqli_connect('localhost','root','','school_db');

    if(!$con){
        die("Connection to this Database failed due to ".mysqli_connect_error());
    }

    $errors=array();

    if(isset($_POST['sub'])){
        $email = $_POST['email'];
        $pssd = $_POST["pssd"];

        if (empty($email)) {
            array_push($errors, "Email is required !!");
        }
        if (empty($pssd)) {
            array_push($errors, "Password is required !!");
        }

        if (count($errors) == 0) {
            $query = "SELECT * FROM `login` WHERE `email` LIKE '$email' AND `password` LIKE '$pssd'";
            $results = mysqli_query($con, $query);
            if (mysqli_num_rows($results) == 1){
                header('location: h1.html');
            }
            else{
                array_push($errors, "Wrong Email/password !!!");
            }
        }
    }
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sharadha_High_School</title>
    <link rel="stylesheet" href="login1.css">
</head>

<body>
    <div class="main">
        <div class="navbar">
            <div class="icon">
                <h2 class="logo">Sharadha High School</h2>
                <ul>
                    <li><a href="h2.html">Home</a></li>
                </ul>
            </div>

        </div>
        <div class="content">
            <h1>SRI SHARADHA <br><span>HIGH SCHOOL</span> <br>@ KODAGU</h1>
            <p class="par">Welcome to Shri Sharadha_High_School Management Login System<br>
            To Login into this School Management SYstem First Get Registered using Sign_up Button<br> 
            Let us get you inside School Management Sytem <br> 
            please type your credentials in the "Login Here" Block.
            </p>

            <a href="index.php"><button class="cn">Sign Up</button></a>

            <div class="form">
                <?php if(count($errors) != 0): ?>
                    <div class="pp">
                        <?php foreach ($errors as $error) : ?>
                        <p><?php echo $error ?></p>
                        <?php endforeach ?>
                    </div>
                <?php  endif ?>
                <form method="post" action="index1.php">  
                    <h2>LOGIN HERE</h2>
                    <input type="email" name="email" placeholder="Enter your email here ">
                    <input type="password" name="pssd" placeholder="Enter your password here ">
                    <a href="#"><button class="btnn" name="sub">LOGIN</button></a>
    
                    <p class="link">Don't have an account ? <br>
                    <a href="index.php">Sign Up</a> Here</p>
                </form>
            </div>

        </div>
    </div>
    </div>
</body>

</html>