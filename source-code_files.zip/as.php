<?php
    $server="localhost";
    $username="root";
    $password="";
    $database="school_db";
    $flag='F';
    
    $con=mysqli_connect($server,$username,$password,$database);
    
    if(!$con){
        die("Connection to this Database failed due to ".mysqli_connect_error());
    }
    

    $errors = array(); 
    
    if(isset($_POST['sub'])){

        $name = $_POST['name'];
        $age = $_POST["age"];
        $gender = $_POST["gender"];
        $phone = $_POST["phone"];
        $class_id = $_POST["class"];
        $section = $_POST["section"];

        $sql="INSERT INTO `student` (`name`, `age`, `gender`, `phone`, `class_id`) VALUES ('$name', '$age', '$gender', '$phone', '$class_id');";

        if (empty($name)) { array_push($errors, "Student name is required !!"); }
        if (empty($age)) { array_push($errors, "Student age is required !!"); }
        if (empty($phone)) { array_push($errors, "Student Phone Number is required !!"); }

        if (count($errors) == 0){
            if($con->query($sql) == true){
                $flag='T';
            }
        }
    }

    $con->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Travel Form</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto|Sriracha&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="input.css">
    
</head>

<body>
    <div class="container">
        <h1>Welcome to Shri Sharadha HighSchool Student Registration form</h3>
        <p>Enter new student details and submit this form below</p>
        <?php if($flag == 'T'): ?>
            <p class='submitMsg'>Thanks for submitting your form. New student is successfully registered, goto home page</p>
        <?php endif ?>
        
        <form method="post" action="./as.php">
            <?php if(count($errors) != 0): ?>
                <div class="pp">
                    <?php foreach ($errors as $error) : ?>
                    <p><?php echo $error ?></p>
                    <?php endforeach ?>
                </div>
            <?php  endif ?>
            
            <input type="text" name="name" placeholder="Enter Student name"> <br>
            <input type="number" name="age" placeholder="Enter Student age"> <br>
            
            <div class="op">
                <label for="gender">Pick students gender</label> 
                <select name="gender" id="gender">
                    <option name="gender" value="male">Male</option>
                    <option name="gender" value="female">Female</option>
                </select>
            </div>
            
            <input type="number" name="phone" placeholder="Enter Students Phone Number"> <br>
            
            <div class="op">
                <label for="class">Class Assigned</label> 
                <select name="class" id="class">
                    <option name="class" value="1">8th   'A'</option>
                    <option name="class" value="2">8th   'B'</option>
                    <option name="class" value="3">8th   'C'</option>
                    <option name="class" value="4">9th   'A'</option>
                    <option name="class" value="5">9th  'B'</option>
                    <option name="class" value="6">9th  'C'</option>
                    <option name="class" value="7">10th  'A'</option>
                    <option name="class" value="8">10th  'B'</option>
                    <option name="class" value="9">10th  'C'</option>
                </select>
            </div> <br>
            
            <button class="btn" name="sub">Submit</button> <br>

            <div>
                <p class="link"> Finished adding the students ? <br> <a href="h1.html">Go back</a>  here</p>
            </div>
        </form>
    </div>
</body>
</html>