<?php
           
    $server="localhost";
    $username="root";
    $password="";
    $database="school_db";
    $flag='F';
    
    $con=mysqli_connect($server,$username,$password,$database);
    
    if(!$con){
        die("Connection to this Database failed due to ".mysqli_connect_error());
    }
    

    $errors = array(); 
    
    if(isset($_POST['sub'])){
        $email = $_POST['email'];
        $name = $_POST['name'];
        // $age = $_POST["age"];
        // $gender = $_POST["gender"];
        $pssd = $_POST["pssd"];
        $pssd1=$_POST["pssd1"];
        // $desig = $_POST["desig"];
        $sql="INSERT INTO `login` (`email`, `password`, `name`, `date_time`) VALUES ('$email', '$pssd', '$name', current_timestamp());";

        if (empty($email)) { array_push($errors, "Email is required !!"); }
        if (empty($name)) { array_push($errors, "Username is required !!"); }
        if (empty($pssd)) { array_push($errors, "Password is required !!"); }
        if ($pssd != $pssd1) {
            array_push($errors, "The two passwords do not match !!");
        }
        
        $user_check_query = "SELECT * FROM `login` WHERE `email` LIKE '$email' OR `name` LIKE '$name'";
        $result = mysqli_query($con, $user_check_query);
        $user = mysqli_fetch_assoc($result);
        
        if ($user) { // if user exists
          if ($user['name'] === $name) {
            array_push($errors, "Username already exists !!");
          }
      
          if ($user['email'] === $email) {
            array_push($errors, "Email already exists !!");
          }
        }

        if (count($errors) == 0){
            if($con->query($sql) == true){
                $flag='T';
            }
        }
    }

    $con->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Travel Form</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto|Sriracha&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="input.css">
    
</head>

<body>
    <div class="container">
        <h1>Welcome to Shri Sharadha HighSchool Registration form</h3>
        <p>Enter your details and submit this form to complete your Sign up </p>
        <?php if($flag == 'T'): ?>
            <p class='submitMsg'>Thanks for submitting your form. You are now successfully registered, goto log-in</p>
        <?php endif ?>
        <form method="post" action="./index.php">
            <?php if(count($errors) != 0): ?>
                <div class="pp">
                    <?php foreach ($errors as $error) : ?>
                    <p><?php echo $error ?></p>
                    <?php endforeach ?>
                </div>
            <?php  endif ?>
            <input id="ad" type="text" name="name" placeholder="Enter your username"> <br>
            <!-- <input type="number" name="age" placeholder="Enter your age">
            <div class="op">
                <label for="gender">Pick your gender</label> 
                <select name="gender" id="gender">
                    <option name="gender" value="male">Male</option>
                    <option name="gender" value="female">Female</option>
                </select>
            </div> -->
            <input type="email" name="email" id="email" placeholder="Enter your email"> <br>
            <input type="password" name="pssd" id="pssd" placeholder="Enter your password"> <br>
            <input type="password" name="pssd1" id="repssd" placeholder="Renter the same password"> <br>
            <!-- <div class="op">
                <label for="desig">Pick your designation</label> 
                <select name="desig" id="desig">
                    <option name="desig" value="teacher">Teacher</option>
                    <option name="desig" value="student">Student</option>
                </select>
            </div> -->
            
            <button class="btn" name="sub">Submit</button> <br>

            <div>
                <p class="link"> Already have an account ? <br> <a href="index1.php">Log in</a>  here</p>
            </div>
        </form>
    </div>
    <script src="index.js"></script>

</body>
</html>
